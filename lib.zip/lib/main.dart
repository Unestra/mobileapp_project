import 'package:flutter/material.dart';
import 'package:myapp/project.dart';


 // Update this import to match your file structure
import 'package:shared_preferences/shared_preferences.dart';



void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Add this line to initialize Flutter binding
  runApp(
    MaterialApp(
      home: FirstPage(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
