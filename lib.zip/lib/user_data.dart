// user_data.dart
List<Map<String, String>> registeredUsers = [
  {'username': 'panama',
      'email': 'doc@test.com',
      'password': '123456',
      'role':  'student'
},
 {'username': 'ekk',
      'email': 'ekk@test.com',
      'password': '1111',
      'role':  'student'
},
  {'username': 'Thongchai',
      'email': 'doc@test.com',
      'password': '123456789',
      'role':  'staff'
},
 {'username': 'Therdsok',
      'email': 'doc@test.com',
      'password': '123456',
      'role':  'lender',
}
];
